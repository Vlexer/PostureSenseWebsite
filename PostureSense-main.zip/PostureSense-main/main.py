from login import LoginWindow

if __name__ == "__main__":
    login_window = LoginWindow()
    login_window.run()